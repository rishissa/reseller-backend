'use strict';

/**
 * plan-metric service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::plan-metric.plan-metric');
