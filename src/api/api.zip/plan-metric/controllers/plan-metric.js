'use strict';

/**
 * plan-metric controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::plan-metric.plan-metric');
