'use strict';

/**
 * plan-metric router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::plan-metric.plan-metric');
