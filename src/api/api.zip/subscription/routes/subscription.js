'use strict';

/**
 * subscription router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::subscription.subscription');
