'use strict';

/**
 * free-plan router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::free-plan.free-plan');
