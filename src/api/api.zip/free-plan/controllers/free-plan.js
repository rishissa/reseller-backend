'use strict';

/**
 * free-plan controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::free-plan.free-plan');
