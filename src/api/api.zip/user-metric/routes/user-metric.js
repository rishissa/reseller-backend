'use strict';

/**
 * user-metric router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::user-metric.user-metric');
