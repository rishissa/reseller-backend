'use strict';

/**
 * user-metric controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::user-metric.user-metric');
