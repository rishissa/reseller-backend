'use strict';

/**
 * product-metric service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::product-metric.product-metric');
