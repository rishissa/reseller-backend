'use strict';

/**
 * product-metric controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::product-metric.product-metric');
