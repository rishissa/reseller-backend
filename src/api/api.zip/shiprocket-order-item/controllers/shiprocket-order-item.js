'use strict';

/**
 * shiprocket-order-item controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::shiprocket-order-item.shiprocket-order-item');
