'use strict';

/**
 * shiprocket-order-item service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::shiprocket-order-item.shiprocket-order-item');
