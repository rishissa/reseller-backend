'use strict';

/**
 * shiprocket-order-item router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::shiprocket-order-item.shiprocket-order-item');
