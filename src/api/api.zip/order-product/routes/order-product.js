'use strict';

/**
 * order-product router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::order-product.order-product');
