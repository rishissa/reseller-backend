'use strict';

/**
 * sub-category service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::sub-category.sub-category');
