'use strict';

/**
 * ship-rocket-order service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::ship-rocket-order.ship-rocket-order');
