'use strict';

/**
 * payment-log controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::payment-log.payment-log');
