'use strict';

/**
 * pin-code router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::pin-code.pin-code');
