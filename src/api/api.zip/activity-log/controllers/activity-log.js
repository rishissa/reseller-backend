'use strict';

/**
 * activity-log controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::activity-log.activity-log');
