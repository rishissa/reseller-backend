'use strict';

/**
 * activity-log router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::activity-log.activity-log');
