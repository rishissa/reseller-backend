module.exports = `
                                                                </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr> 
                                <tr>
                                                                    <td
                                                                        style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:15px;padding-right:0;padding-bottom:0;padding-left:0;color:#202020;border-top:1px solid #c8c8c8">
                                                                        <table cellspacing="0" cellpadding="0"
                                                                            style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;border-collapse:collapse;border-spacing:0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td
                                                                                        style="width:80%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;text-align:right;font-size:12px;line-height:1.67">
                                                                                        Sub Total
                                                                                    </td>
                                                                                    <td
                                                                                        style="width:20%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;text-align:right;font-size:12px;line-height:1.67">
                                                                                        ₹ {{subtotal}}
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td
                                                                                        style="width:80%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;text-align:right;font-size:12px;line-height:1.67">
                                                                                        Convenience Fee [2% + GST(18%)]
                                                                                    </td>
                                                                                    <td
                                                                                        style="width:20%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;text-align:right;font-size:12px;line-height:1.67">
                                                                                        ₹ {{gst}}
                                                                                    </td>
                                                                                </tr>
                                                                                
                                                                                <tr>
                                                                                    <td
                                                                                        style="width:80%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:15px;padding-right:0;padding-bottom:0;padding-left:0;text-align:right;font-size:16px;line-height:1.67;font-weight:700">
                                                                                        Total Amount</td>
                                                                                    <td
                                                                                        style="width:20%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:15px;padding-right:0;padding-bottom:0;padding-left:0;text-align:right;font-size:16px;line-height:1.67;font-weight:700">

                                                                                        ₹{{total}}

                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>

`;
