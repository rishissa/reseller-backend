module.exports = `
                                                                <tr>
                                                                    <td
                                                                        style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:24px;padding-right:0;padding-bottom:16px;padding-left:0">
                                                                        <table cellspacing="0" cellpadding="0"
                                                                            style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;border-collapse:collapse;border-spacing:0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td
                                                                                        style="width:10%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;vertical-align:top">
                                                                                        <a style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;display:block;text-decoration:none;width:60px"
                                                                                            href="#"
                                                                                            title={{name}}
                                                                                            target="_blank">
                                                                                            <img src="{{image}}"
                                                                                                width="60" height="74"
                                                                                                border="0"
                                                                                                alt={{name}}
                                                                                                class="CToWUd"
                                                                                                data-bit="iit">
                                                                                        </a>
                                                                                    </td>
                                                                                    <td
                                                                                        style="width:70%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:1rem;padding-right:0;padding-bottom:0;padding-left:12px;vertical-align:top;font-size:12px;color:#202020;text-align:left">
                                                                                        <p
                                                                                            style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:8px;padding-left:0;font-weight:700">
                                                                                            <a href="#"
                                                                                                title={{name}}
                                                                                                style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-weight:700;color:#202020"
                                                                                                target="_blank"
                                                                                                >
                                                                                                <span>{{name}}</span>
                                                                                            </a>
                                                                                        </p>
                                                                                        <p
                                                                                            style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:8px;padding-left:0">
                                                                                            <span
                                                                                                style="color:#6d6d6d">Qty</span>
                                                                                            <span
                                                                                                style="font-weight:700">{{qty}}</span>
                                                                                        </p>

                                                                                    </td>
                                                                                    <td
                                                                                        style="width:20%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;vertical-align:top;font-size:14px;color:#202020;font-weight:700;line-height:1.57;text-align:right">
                                                                                        ₹ {{price}}
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                                `;
