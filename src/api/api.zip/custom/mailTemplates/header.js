module.exports = `<tr>
    <td
        style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px;background:black;background-color:black;color:#ffffff">
        <table cellspacing="0" cellpadding="0"
            style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;border-collapse:collapse;border-spacing:0">
            <tbody>
                <tr>
                    <td
                        style="width:20%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;text-align:left">
                        <a href="#" title="Reseller App" target="_blank"
                            data-saferedirecturl="https://www.google.com/url?q=http://www.ajio.com&amp;source=gmail&amp;ust=1678874982781000&amp;usg=AOvVaw3ZgGwvxAmlhu9GB1MKJZcY">
                            <img style="vertical-align:middle"
                                src="../../../../public/uploads/loginImage.jpeg"
                                width="113" height="33" border="0" alt="Reseller App" class="CToWUd" data-bit="iit">
                        </a>
                    </td> 
                    <td
                        style="width:80%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;color:#ffffff">
                        <table cellspacing="0" cellpadding="0"
                            style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;border-collapse:collapse;border-spacing:0">
                            <tbody>
                                <tr>
                                    <td
                                        style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;text-align:right;font-size:20px;font-weight:600;color:#ffffff">
                                        {{order_status}}</td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;text-align:right;font-size:12px;color:#ffffff">
                                        Order ID <a style="font-weight:600;color:#ffffff;text-decoration:underline"
                                            href="#"
                                            target="_blank"
                                            >{{orderid}}</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </td>
</tr>`;
{
  /* <td
                        style="width:20%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;text-align:left">
                        <a href="http://www.ajio.com" title="AJIO" target="_blank"
                            data-saferedirecturl="https://www.google.com/url?q=http://www.ajio.com&amp;source=gmail&amp;ust=1678874982781000&amp;usg=AOvVaw3ZgGwvxAmlhu9GB1MKJZcY">
                            <img style="vertical-align:middle"
                                src="https://ci5.googleusercontent.com/proxy/Q5zi2MimhztqyuzMbsvmvffoNi9utIK9Ht3vQrQ4vYe69BDLQbvdSUTJeaARgxaz4LcgHOzF7EdF5vrf7D7Pv_2gVFYXJ1iL0sCRxdnjXb24d6TBv7XYx0P-KE0q3g=s0-d-e1-ft#http://www.ajio.com/_ui/desktop/theme-rilfnl/images/email/eml-ajio-logo.png"
                                width="113" height="33" border="0" alt="AJIO" class="CToWUd" data-bit="iit">
                        </a>
                    </td> */
}
