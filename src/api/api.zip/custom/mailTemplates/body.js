module.exports = `<tr>
                                    <td
                                        style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-size:14px;font-weight:normal;line-height:1.29;color:#202020;text-align:left">
                                        <table cellspacing="0" cellpadding="0"
                                            style="width:100%;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;border-collapse:collapse;border-spacing:0">
                                            <tbody>
                                                <tr>
                                                    <td
                                                        style="width:100%;text-align:left;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0">
                                                        <p
                                                            style="width:100%;margin-top:0;margin-right:0;margin-bottom:15px;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-size:14px;line-height:1.29;color:#202020">
                                                            Hi <b>{{name}}</b>,</p>
                                                        <p
                                                            style="width:100%;margin-top:0;margin-right:0;margin-bottom:15px;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-size:14px;line-height:1.29;color:#202020">
                                                            {{message}}.</p>
                                                        {{{note}}}
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>`;
