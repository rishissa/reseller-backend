module.exports=`<tr>
    <td
        style="width:100%;font-size:12px;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px;background:#d6ffef;text-align:left;font-size:14px;font-weight:normal;line-height:18px;color:#393939">
        {{message}}.
    </td>
</tr>`