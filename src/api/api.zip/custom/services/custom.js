'use strict';

/**
 * custom service
 */

module.exports = () => ({});
