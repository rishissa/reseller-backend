'use strict';

/**
 * global-brand controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::global-brand.global-brand');
