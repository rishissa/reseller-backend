'use strict';

/**
 * global-brand router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::global-brand.global-brand');
