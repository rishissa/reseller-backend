'use strict';

/**
 * product-variant service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::product-variant.product-variant');
