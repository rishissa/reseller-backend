"use strict";

/**
 * product-variant controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController("api::product-variant.product-variant");
