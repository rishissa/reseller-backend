'use strict';

/**
 * store-setting controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::store-setting.store-setting');
