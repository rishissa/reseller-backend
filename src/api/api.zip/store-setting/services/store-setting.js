'use strict';

/**
 * store-setting service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::store-setting.store-setting');
