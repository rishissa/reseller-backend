'use strict';

/**
 * store-setting router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::store-setting.store-setting');
