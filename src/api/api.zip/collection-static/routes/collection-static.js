'use strict';

/**
 * collection-static router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::collection-static.collection-static');
