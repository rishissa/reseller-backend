'use strict';

/**
 * bulk-pricing controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::bulk-pricing.bulk-pricing');
